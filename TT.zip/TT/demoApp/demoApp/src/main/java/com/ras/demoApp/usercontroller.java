package com.ras.demoApp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value= "/api/users")
public class usercontroller {
    @Autowired
    private UserService userService;

    @GetMapping("/create")
    public ResponseEntity<String> createUser(@RequestParam String username) {
        userService.createUser(username);
        return ResponseEntity.ok("User created successfully");
    }

    @GetMapping("/create-programmatic")
    public ResponseEntity<String> createUserProgrammatically(@RequestParam String username) {
        System.out.println("inside creatUserMethod Method test:"+ Thread.currentThread().getName());
        userService.createUserProgrammatically(username);
        return ResponseEntity.ok("User created programmatically successfully");
    }

}
