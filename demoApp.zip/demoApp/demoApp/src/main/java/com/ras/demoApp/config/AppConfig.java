/*
package com.ras.demoApp.config;

import com.ras.demoApp.respository.MyRepository;
import com.ras.demoApp.respository.MyRepositoryImpl;
import com.ras.demoApp.service.MyService;
import com.ras.demoApp.service.MyServiceImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

}
*/
