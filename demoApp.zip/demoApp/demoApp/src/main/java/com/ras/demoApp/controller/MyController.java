package com.ras.demoApp.controller;

import com.ras.demoApp.service.MyService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class MyController {
    private final MyService myService;

    // Constructor-based DI
    public MyController(MyService myService) {
        this.myService = myService;
    }

    @GetMapping("/process/{input}")
    public ResponseEntity<String> process(@PathVariable String input) {
        String result = myService.performOperation(input);
        return ResponseEntity.ok(result);
    }
}
