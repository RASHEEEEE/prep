package com.ras.demoApp.respository;

public interface MyRepository {
    String getData(String input);
}