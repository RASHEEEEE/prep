package com.ras.demoApp.respository;

import com.ras.demoApp.respository.MyRepository;
import org.springframework.stereotype.Repository;

@Repository
public class MyRepositoryImpl implements MyRepository {
    @Override
    public String getData(String input) {
        return "Data for " + input;
    }
}
