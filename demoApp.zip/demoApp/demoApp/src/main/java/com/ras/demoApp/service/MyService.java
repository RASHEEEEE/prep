package com.ras.demoApp.service;

public interface MyService {
    String performOperation(String input);
}
