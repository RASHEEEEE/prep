package com.ras.demoApp.service;

import com.ras.demoApp.respository.MyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MyServiceImpl implements MyService {
    private final MyRepository myRepository;

    // Constructor-based DI
    @Autowired
    public MyServiceImpl(MyRepository myRepository) {
        this.myRepository = myRepository;
    }


    @Override
    public String performOperation(String input) {
        return "Processed: " + myRepository.getData(input);
    }
}
