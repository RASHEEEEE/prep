package com.ras.demoApp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

@Service
public class UserService {
    @Autowired
    private TransactionTemplate transactionTemplate;

    @Autowired
    private UserRepository userRepository;
    @Transactional
    public void createUser(String username) {
        User user = new User();
        user.setUsername(username);
        userRepository.save(user);
        // Other operations can be added here
    }

    public void createUserProgrammatically(String username) {
        transactionTemplate.execute(new TransactionCallback<Void>() {
            @Override
            public Void doInTransaction(TransactionStatus status) {
                try {
                    User user = new User();
                    user.setUsername(username);
                    userRepository.save(user);
                    // Other operations can be added here
                } catch (Exception e) {
                    status.setRollbackOnly();
                }
                return null;
            }
        });
    }
}
